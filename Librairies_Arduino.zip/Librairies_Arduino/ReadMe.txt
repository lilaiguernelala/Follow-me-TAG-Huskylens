Coller ces r�pertoires dans le r�pertoire � user/ Documents\Arduino\libraries �
red�marrer l�interface arduino, les librairies sont maintenant disponibles.
